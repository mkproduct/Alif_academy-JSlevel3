import React from "react";
import "./Post.css";

export default function Post({ post }) {
  const { author } = post;
  return (
    <article>
      <header>
        <img src={author.avatar} alt={author.name} width="50" height="50" className="Post-avatar" />
        <h5>{author.name}</h5>
        <div>{post.created}</div>
        {post.hit && <span>HIT</span>}
      </header>
      <div>
        <div className="Post-content">{post.content}</div>
        <img src={post.photo} alt="photo" className="Post-photo" />
      </div>
      <footer>
        <span className="Post-likes">
          <img src={`https://lms.openjs.io/${post.likedByMe ? "liked" : "unliked"}.svg`} width="20" height="20" />
          <span className="Post-likes-count">{post.likes}</span>
        </span>
      </footer>
    </article>
  );
}
