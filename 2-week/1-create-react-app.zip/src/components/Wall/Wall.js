import React from "react";
import Post from "../Post/Post";

function Wall() {
  const post = [
    {
      id: 2,
      author: {
        id: 1,
        avatar: "https://lms.openjs.io/logo_js.svg",
        name: "OpenJS",
      },
      content: "Ну как, вы справились с домашкой?",
      photo: null,
      hit: true,
      likes: 222,
      likedByMe: true,
      created: 1603774800,
      tags: ["deadline", "homework"],
    },
    {
      id: 1,
      author: {
        id: 1,
        avatar: "https://lms.openjs.io/logo_js.svg",
        name: "OpenJS",
      },
      content: null,
      photo: {
        url: "https://lms.openjs.io/openjs.jpg",
        alt: "openjs logo",
      },
      hit: true,
      likes: 10,
      likedByMe: true,
      created: 1603501200,
      tags: null,
    },
  ];

  return (
    <div>
      {post.map((o) => (
        <Post key={o.id} post={o} />
      ))}
    </div>
  );
}

export default Wall;
