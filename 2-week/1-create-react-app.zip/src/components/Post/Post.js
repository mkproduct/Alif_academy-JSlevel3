import React from "react";
import Tags from "../Tags/Tags";
import "./Post.css";

export default function Post({ post }) {
  const { author, photo } = post;
  return (
    <article>
      <header>
        <img src={author.avatar} alt={author.name} width="50" height="50" className="Post-avatar" />
        <h5>{author.name}</h5>
        <div>{post.created}</div>
        {post.hit && <span>HIT</span>}
      </header>
      <div>
        <div className="Post-content">{post.content}</div>
        {photo && <img src={photo.url} alt={photo.alt} className="Post-photo" />}
      </div>
      <footer>
        <span className="Post-likes">
          <img
            src={`https://lms.openjs.io/${post.likedByMe ? "liked" : "unliked"}.svg`}
            alt="likes"
            width="20"
            height="20"
          />
          <span className="Post-likes-count">{post.likes}</span>
          {post.tags && <Tags tags={post.tags} />}
        </span>
      </footer>
    </article>
  );
}
