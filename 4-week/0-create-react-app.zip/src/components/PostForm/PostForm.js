import React, { useState, useRef, useEffect } from "react";

const initialData = {
  id: 0,
  author: { avatar: "https://lms.openjs.io/logo_js.svg", name: "OpenJS" },
  content: "",
  photo: null,
  hit: false,
  likes: 0,
  likedByMe: false,
  hidden: false,
  tags: null,
  created: 0,
};

export default function PostForm({ edited = initialData, onSave, onCancel }) {
  const [post, setPost] = useState(edited);
  const firstFocusEl = useRef(null);

  useEffect(() => {
    setPost(edited);
  }, [edited]);

  // submit
  // prettier-ignore
  const handleSubmit = (ev) => {
    console.log('object');
    ev.preventDefault();
    const photo = post.photo !== null && post.photo.url && post.photo.url.length ? { url: "", alt: "", ...post.photo } : null;
    let tags = post.tags?.map((o) => o.replace(/#/gi, "")).filter((o) => o.length) || [];
    tags = tags.length ? tags : null;

    onSave({ ...post, id: post.id || Date.now(), created: post.created || Date.now(), tags, photo });
    setPost(initialData);
    firstFocusEl.current.focus();
  };

  // onChange
  const handleChange = (ev) => {
    const { name, value } = ev.target;
    switch (name) {
      case "tags":
        const parsed = value.split(" ");
        setPost((prevState) => ({ ...prevState, [name]: parsed }));
        break;
      case "photo":
        setPost((prevState) => ({ ...prevState, photo: { ...prevState.photo, url: value } }));
        break;
      case "alt":
        setPost((prevState) => ({ ...prevState, photo: { ...prevState.photo, alt: value } }));
        break;
      default:
        setPost((prevState) => ({ ...prevState, [name]: value }));
        break;
    }
  };

  // RENDER
  return (
    <>
      <form onSubmit={handleSubmit}>
        <textarea name="content" value={post.content || ""} onChange={handleChange} ref={firstFocusEl} />
        <input name="tags" value={post.tags?.join(" ") || ""} onChange={handleChange} />
        <input name="photo" value={post.photo?.url || ""} placeholder="photo" onChange={handleChange} />
        <input name="alt" value={post.photo?.alt || ""} placeholder="alt" onChange={handleChange} />
        <button>Ok</button>
      </form>
      {edited !== initialData && <button onClick={onCancel}>Отменить</button>}
    </>
  );
}
