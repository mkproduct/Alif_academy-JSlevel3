import React, { useRef, useContext } from "react";
import PostsContext from "../../contexts/PostsContext";
import { editSubmit, editChange, editCancel } from "../../store/actions";

export default function PostForm() {
  const {
    state: { edited },
    dispatch,
  } = useContext(PostsContext);
  const firstFocusEl = useRef(null);

  // submit
  const handleSubmit = (ev) => {
    ev.preventDefault();
    dispatch(editSubmit());
    firstFocusEl.current.focus();
  };

  // onChange
  const handleChange = (ev) => {
    const { name, value } = ev.target;
    dispatch(editChange(name, value));
  };

  // reset
  const handleReset = () => {
    dispatch(editCancel());
  };

  // RENDER
  return (
    <>
      <form onSubmit={handleSubmit}>
        <textarea name="content" value={edited.content || ""} onChange={handleChange} ref={firstFocusEl} />
        <input name="tags" value={edited.tags?.join(" ") || ""} onChange={handleChange} />
        <input name="photo" value={edited.photo?.url || ""} placeholder="photo" onChange={handleChange} />
        <input name="alt" value={edited.photo?.alt || ""} placeholder="alt" onChange={handleChange} />
        <button>Ok</button>
      </form>
      {edited.id !== 0 && <button onClick={handleReset}>Отменить</button>}
    </>
  );
}

// SUBMIT
