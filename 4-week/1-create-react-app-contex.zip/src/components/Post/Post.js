import React, { useContext } from "react";
import PostsContext from "../../contexts/PostsContext";
import Tags from "../Tags/Tags";
import "./Post.css";

import { like, remove, hide, edit } from "../../store/actions";

export default function Post({ post }) {
  const { dispatch } = useContext(PostsContext);
  const { author, photo } = post;

  const handleLike = () => {
    dispatch(like(post.id));
  };

  const handleRemove = () => {
    dispatch(remove(post.id));
  };

  const handleHide = () => {
    dispatch(hide(post.id));
  };

  const handleEdit = () => {
    dispatch(edit(post.id));
  };

  const header = (
    <header>
      <img src={author.avatar} alt={author.name} width="50" height="50" className="Post-avatar" />
      <h5>{author.name}</h5>
      {!post.hidden && <button onClick={handleRemove}>удалить</button>}
      <button onClick={handleHide}>{post.hidden ? "показать" : "скрыть"}</button>
      <button onClick={handleEdit}>изменить</button>
      {!post.hidden && <div>{post.created}</div>}
      {!post.hidden && post.hit && <span>HIT</span>}
    </header>
  );

  // RENDER
  if (post.hidden) {
    return <article>{header}</article>;
  }

  return (
    <article>
      {header}
      <div>
        <div className="Post-content">{post.content}</div>
        {photo && <img src={photo.url} alt={photo.alt} className="Post-photo" />}
      </div>
      <footer>
        <span className="Post-likes" onClick={handleLike}>
          <img
            src={`https://lms.openjs.io/${post.likedByMe ? "liked" : "unliked"}.svg`}
            alt="likes"
            width="20"
            height="20"
          />
          <span className="Post-likes-count">{post.likes}</span>
          {post.tags && <Tags tags={post.tags} />}
        </span>
      </footer>
    </article>
  );
}
