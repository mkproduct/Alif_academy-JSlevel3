import {
  POST_EDIT_SUBMIT,
  POST_EDIT_CHANGE,
  POST_EDIT_CANCEL,
  POST_LIKE,
  POST_REMOVE,
  POST_HIDE,
  POST_EDIT,
} from "../actions";

const empty = {
  id: 0,
  author: { avatar: "https://lms.openjs.io/logo_js.svg", name: "OpenJS" },
  content: "",
  photo: null,
  hit: false,
  likes: 0,
  likedByMe: false,
  hidden: false,
  tags: null,
  created: 0,
};

export const initialState = {
  posts: [],
  edited: empty,
};

export const reducer = (state = initialState, action) => {
  switch (action.type) {
    case POST_EDIT_SUBMIT:
      return reduceSubmit(state, action);
    case POST_EDIT_CHANGE:
      return reduceChange(state, action);
    case POST_EDIT_CANCEL:
      return reduceCancel(state, action);
    case POST_LIKE:
      return reduceLike(state, action);
    case POST_REMOVE:
      return reduceRemove(state, action);
    case POST_HIDE:
      return reduceToggleVisibility(state, action);
    case POST_EDIT:
      return reduceEdit(state, action);
    default:
      return state;
  }
};

// POST FORM
const reduceSubmit = (state, action) => {
  const { posts, edited } = state;
  // prettier-ignore
  const parsed = edited.tags?.map((o) => o.replace(/#/gi, "")).filter((o) => o.length) || [];
  const tags = parsed.length ? parsed : null;
  const post = {
    ...edited,
    id: edited.id || Date.now(),
    created: edited.created || Date.now(),
    tags,
    photo: edited.photo?.url ? { alt: "", ...edited.photo } : null,
  };

  // add
  if (edited?.id === 0) {
    return {
      ...state,
      posts: [{ ...post }, ...posts],
      edited: empty,
    };
  }

  // edit
  return {
    ...state,
    posts: posts.map((o) => {
      if (o.id !== post.id) {
        return o;
      }
      return { ...post };
    }),
    edited: empty,
  };
};

const reduceChange = (state, action) => {
  // prettier-ignore
  const { payload: {name, value} } = action
  const { edited } = state;

  if (name === "tags") {
    const parsed = value.split(" ");
    // prettier-ignore
    return { ...state, edited: { ...edited, [name]: parsed }, };
  }

  if (name === "photo" || name === "alt") {
    const prop = name === "photo" ? "url" : name;
    return { ...state, edited: { ...edited, [prop]: value } };
  }

  return { ...state, edited: { ...edited, [name]: value } };
};

const reduceCancel = (state, action) => {
  return {
    ...state,
    edited: empty,
  };
};

// POST
const reduceLike = (state, action) => {
  // prettier-ignore
  const {payload: {id}} = action
  return {
    ...state,
    posts: state.posts.map((o) => {
      if (o.id !== id) {
        return o;
      }
      const likedByMe = !o.likedByMe;
      const likes = likedByMe ? o.likes + 1 : o.likes - 1;
      return { ...o, likedByMe, likes };
    }),
  };
};

const reduceRemove = (state, action) => {
  // prettier-ignore
  const {payload: {id}} = action
  return { ...state, posts: state.posts.filter((o) => o.id !== id) };
};

const reduceEdit = (state, action) => {
  // prettier-ignore
  const {payload: {id}} = action
  const post = state.posts.find((o) => o.id === id);

  if (post === undefined) {
    return state;
  }

  return {
    ...state,
    edited: post,
  };
};

const reduceToggleVisibility = (state, action) => {
  // prettier-ignore
  const {payload: {id}} = action
  return {
    ...state,
    posts: state.posts.map((o) => {
      if (o.id !== id) {
        return o;
      }
      return { ...o, hidden: !o.hidden };
    }),
  };
};
